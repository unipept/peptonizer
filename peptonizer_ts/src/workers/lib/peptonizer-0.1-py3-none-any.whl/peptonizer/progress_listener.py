from enum import Enum


class ProgressStep(Enum):
    TaxonAnalysis = "taxon_analysis",
    WeightTaxa = "weight_taxa",
    CreateGraph = "create_graph",
    RunBeliefPropagation = "run_belief_propagation"


class ProgressListener:
    def progress_updated(self, progress: float, step_type: ProgressStep):
        pass
